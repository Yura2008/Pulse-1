# Pulse — Android (Kotlin + Jetpack Compose)

## Status (2026-11-03)

**This archive is source code, NOT a compiled APK.** The environment used to prepare it had no Android SDK, Gradle, emulator or internet access for installing build dependencies. **No compile/install/device integration/pixel-difference test has been completed.** Before distributing, run the GitHub workflow or build in Android Studio, resolve compiler issues if any, install on an actual Samsung device, then test all Health Connect permissions and synchronized data types. These are required verification steps, not claimed accomplishments.

The visual source of truth is the 13 reference PNG files and `references/design-contract.json`, reproduced in a native Compose implementation using the design tokens. This is a first implementation, **not verified pixel-identical**.

## Android build

Requirements: JDK 17, Android SDK 36, Android Gradle Plugin 8.10.1, Gradle 8.11.1, an internet connection to Google's Maven repository, and a connected Android phone for verification. The project deliberately has no Gradle wrapper JAR because this environment cannot fetch it. With Gradle 8.11.1 available:

```bash
gradle :app:assembleDebug
# APK appears at app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Build APK from a phone (GitHub Actions)

1. Create a **private** GitHub repository and upload the project contents including the `.github/workflows/build-apk.yml` directory (not just the outer ZIP).
2. Open the repository's **Actions** tab; select **Build Pulse APK** and tap **Run workflow**. A push to `main` can also trigger it.
3. After a successful run, open the run, scroll to **Artifacts**, download **Pulse-debug-APK** and extract its ZIP to get `app-debug.apk`.
4. Install on the Android phone, grant permissions to Health Connect, verify data and compare screens with references. This project has not yet had a successful Actions build; do not assume it will build without corrections.

The uploaded build artifact is a debug-signed APK for personal testing, **not** a Play Store release. Do not upload health reports to public repositories.

## Samsung Galaxy Watch -> Samsung Health -> Health Connect -> Pulse

Pulse does not use a proprietary direct Samsung Watch API. Per Samsung's official integration, Samsung Health on the phone exports supported types to Health Connect. Pulse reads them in the **foreground** after the user grants explicit Health Connect permissions:

- Heart rate, resting heart rate, blood oxygen/SpO2, sleep sessions and stages.
- Steps; distance; active and total calories (if synced); exercise sessions.
- Body weight and body fat (if present).

**Phone setup:**

1. Open Galaxy Wearable / Samsung Health, ensure the watch is paired and Samsung Health has synced current measurements.
2. In Samsung Health -> Settings -> Health Connect -> app permissions, enable sharing of the data categories.
3. In Pulse -> Settings -> Request read permissions, approve desired categories.
4. Tap **Sync now** and see when the last successful request was performed. Missing data remain missing, never become demo values.

Samsung states that Galaxy Watch continuous heart rate may synchronize later than manual readings. Samsung's activity tracker may not export all daily calorie and distance data, and sleep scores are not a standard Health Connect record. SpO2 and body fat depend on the versions and granted sharing. The app cannot force Samsung Health to write data.

Health Connect normally permits retrieving data from up to 30 days before the initial authorization; this version only reads the latest 30 days on sync. Records already received are persisted locally. A broader initial import requires a separately granted historical data permission and a later code change.

## Screens

13 native routes: Dashboard, heart rate, oxygen, sleep, steps (14-day default, 7/14/30 filtering), exercise, history, reports, sync, goals, weight, no-data and permission explanation. Navigation is native and interactive rather than overlay hotspots on screenshots.

## Reports

Exports Markdown (.md) and machine-readable JSON to user-selected files; includes timestamp, source per reading, units, history, statistics, daily steps and personal notes. User can share a file via Android share sheet including with ChatGPT, if ChatGPT is installed. There is **no automatic ChatGPT AI API integration**. Reports warn that they are not clinical advice.

## Privacy

- Data is written to an on-device, app-private SQLite database; backups are disabled.
- No INTERNET permission, no cloud endpoint, no analytics SDK, no advertisements.
- Export/sharing is exclusively user-triggered. The user may delete data via app clear-storage/uninstall.
- Only read Health Connect permissions are requested; the app does not modify existing health records.
- Native permission rationale available in `PermissionsRationaleActivity`.

## Limitations to test before release

- Compilation and runtime compatibility, data type permissions, actual Samsung watch/phone synchronization.
- Translation of bitmap reference geometry and type metrics to Compose UI is **not measured pixel-identical**.
- Aggregating raw step/distance/calorie intervals prefers Samsung Health source when present to avoid combining competing providers, but overlapping intervals within one source could still overcount; a future release should use Health Connect aggregate APIs and source priority for definitive totals.
- UI recalculates local trends when syncing on foreground. No continuous background sync, no live watch stream, no direct Samsung login.
- `Steps` chart and date details use real values or mark days missing, never zero-filling unrecorded days.
- Detailed health interpretation requires exporting and optionally sharing the report with ChatGPT manually.

## Authoritative docs

- https://developer.samsung.com/health/health-connect-faq.html
- https://developer.samsung.com/health/blog/en/accessing-samsung-health-data-through-health-connect
- https://developer.android.com/health-and-fitness/health-connect/get-started
- https://developer.android.com/jetpack/androidx/releases/health-connect
