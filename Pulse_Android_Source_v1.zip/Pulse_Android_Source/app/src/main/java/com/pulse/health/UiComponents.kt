package com.pulse.health

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.max

object PulseColors {
    val background = Color(0xFFF7F8FD)
    val card = Color.White
    val border = Color(0xFFEDEEF7)
    val text = Color(0xFF1F2340)
    val muted = Color(0xFF8E91A8)
    val primary = Color(0xFF6251E8)
    val primaryLight = Color(0xFFF0EDFF)
    val heart = Color(0xFFEF5E81)
    val oxygen = Color(0xFF3383EF)
    val sleep = Color(0xFF9469E8)
    val activity = Color(0xFF22B68E)
    val headerGradient = Brush.horizontalGradient(listOf(Color(0xFF262B68), Color(0xFF453C9B), Color(0xFF6755CB)))
}

fun formatted(value: Double?, kind: String): String {
    if(value == null) return "—"
    if(kind == Metric.SLEEP) {
        val minutes = value.toInt()
        return "${minutes / 60}:${(minutes % 60).toString().padStart(2, '0')}"
    }
    return if (kind == Metric.WEIGHT || kind == Metric.BODY_FAT || kind == Metric.DISTANCE)
        "%.1f".format(Locale.US, value) else NumberFormat.getIntegerInstance(Locale.US).format(value.toInt())
}
fun timeText(ms: Long): String = DateTimeFormatter.ofPattern("dd/MM, HH:mm", Locale("he", "IL"))
    .withZone(ZoneId.systemDefault()).format(Instant.ofEpochMilli(ms))

@Composable fun PulseCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val cardModifier = modifier.clip(RoundedCornerShape(20.dp)).background(PulseColors.card)
        .border(1.dp, PulseColors.border, RoundedCornerShape(20.dp))
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(16.dp)
    Column(modifier = cardModifier, content = content)
}
@Composable fun Label(text: String, color: Color = PulseColors.muted, size: Int = 13, modifier: Modifier = Modifier) =
    Text(text, modifier, color = color, fontSize = size.sp, lineHeight = (size+5).sp)
@Composable fun Value(text: String, color: Color = PulseColors.text, size: Int = 30, modifier: Modifier = Modifier) =
    Text(text, modifier, color = color, fontSize = size.sp, fontWeight = FontWeight.Bold, lineHeight = (size+7).sp)

@Composable fun PulseSection(title: String, subtitle: String? = null, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 21.sp, color = PulseColors.text)
        if(subtitle!=null) Label(subtitle, size = 12)
    }
}

@Composable fun PulseButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick=onClick, enabled=enabled, modifier=modifier.heightIn(min=48.dp), shape=RoundedCornerShape(13.dp),
        colors=ButtonDefaults.buttonColors(containerColor=PulseColors.primary, contentColor=Color.White)) {
        Text(text, fontWeight=FontWeight.Bold, fontSize=14.sp)
    }
}

@Composable fun PeriodSelector(days: Int, onDays: (Int)->Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PulseColors.primaryLight).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        listOf(7,14,30).forEach { choice ->
            val selected=days==choice
            Box(Modifier.weight(1f).height(38.dp)
                .clip(RoundedCornerShape(12.dp)).background(if(selected) Color.White else Color.Transparent)
                .clickable{onDays(choice)}, contentAlignment=Alignment.Center) {
                Text("$choice ימים", fontWeight=if(selected) FontWeight.Bold else FontWeight.Medium,
                    color=if(selected) PulseColors.primary else PulseColors.muted, fontSize=14.sp)
            }
        }
    }
}

@Composable fun MetricIcon(icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Icon(icon, null, modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(color.copy(alpha=.11f)).padding(10.dp), tint=color)
}
@Composable fun DashboardTile(title: String, reading: String, unit: String, footer: String,
    tint: Color, icon: ImageVector, onClick: () -> Unit, modifier: Modifier=Modifier) {
    PulseCard(modifier.heightIn(min=142.dp), onClick=onClick) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
            Text(title, fontWeight=FontWeight.Bold, fontSize=16.sp, color=PulseColors.text)
            MetricIcon(icon, tint)
        }
        Spacer(Modifier.height(13.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.Bottom) {
            Value(reading, size=27)
            Spacer(Modifier.width(4.dp))
            Label(unit, modifier=Modifier.padding(bottom=5.dp))
        }
        Spacer(Modifier.height(5.dp))
        Label(footer, size=12)
    }
}

@Composable fun CircularGoal(fraction: Float, modifier: Modifier = Modifier, number: String = "") {
    Box(modifier.size(110.dp), contentAlignment=Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            drawArc(PulseColors.primary.copy(alpha=.12f), -90f, 360f, false, style=Stroke(width=12.dp.toPx(), cap=StrokeCap.Round))
            drawArc(PulseColors.primary, -90f, 360f * fraction.coerceIn(0f,1f), false, style=Stroke(width=12.dp.toPx(), cap=StrokeCap.Round))
        }
        Column(horizontalAlignment=Alignment.CenterHorizontally) {
            Value(number.ifBlank { "${(fraction*100).toInt()}%" }, size=20)
            Label("מהיעד", size=11)
        }
    }
}

/** Draws real-time-series data as native Compose pixels; no screenshot overlay. */
@Composable fun NativeChart(values: List<Double?>, color: Color, modifier: Modifier = Modifier, bars: Boolean = false,
    labels: List<String> = emptyList(), onSelect: ((Int) -> Unit)? = null) {
    var selected by remember(values) { mutableIntStateOf(-1) }
    Column(modifier) {
        if (selected in values.indices) {
            val v = values[selected]
            Label("${labels.getOrNull(selected) ?: "יום ${selected + 1}"}: ${if(v == null) "אין נתונים" else "%.1f".format(Locale.US,v)}", color=PulseColors.primary)
            Spacer(Modifier.height(8.dp))
        }
        val finite=values.filterNotNull()
        if (finite.isEmpty()) {
            Box(Modifier.fillMaxWidth().height(165.dp), contentAlignment=Alignment.Center) { Label("אין נתונים לתקופה שנבחרה") }
            return@Column
        }
        val maxV=(finite.maxOrNull() ?: 1.0).coerceAtLeast(1.0)
        val minV= if(bars) 0.0 else (finite.minOrNull() ?: 0.0).let { it - (maxV-it).coerceAtLeast(1.0)*.25 }
        val topV=if(bars) maxV*1.12 else maxV+(maxV-minV)*.18
        Canvas(Modifier.fillMaxWidth().height(180.dp).pointerInput(values) {
            detectTapGestures { off ->
                val i = ((off.x / size.width) * values.size).toInt().coerceIn(0, values.lastIndex)
                selected=i; onSelect?.invoke(i)
            }
        }) {
            val w=size.width; val h=size.height; val top=12.dp.toPx(); val bottom=h-18.dp.toPx()
            for (j in 0..4) {
                val y=top+(bottom-top)*j/4
                drawLine(PulseColors.border, Offset(0f,y),Offset(w,y), strokeWidth=1.dp.toPx())
            }
            fun valY(v: Double): Float = (bottom-(((v-minV)/(topV-minV)).toFloat().coerceIn(0f,1f))*(bottom-top))
            if (bars) {
                val colW=w/values.size.coerceAtLeast(1)
                values.forEachIndexed { i, v ->
                    if (v!=null) {
                        val y=valY(v)
                        drawRoundRect(color.copy(alpha=if(i==selected) 1f else .74f),
                            topLeft=Offset(colW*i+colW*.17f,y),
                            size=androidx.compose.ui.geometry.Size(colW*.66f, bottom-y),
                            cornerRadius=androidx.compose.ui.geometry.CornerRadius(4.dp.toPx()))
                    }
                }
            } else {
                val dx=if (values.size>1) w/(values.size-1) else 0f
                var prev: Offset? = null
                values.forEachIndexed { i, v ->
                    if(v!=null) {
                        val p=Offset(i*dx, valY(v))
                        prev?.let { drawLine(color, it, p, strokeWidth=2.8.dp.toPx(),cap=StrokeCap.Round) }
                        drawCircle(color, radius=4.dp.toPx(),center=p)
                        drawCircle(Color.White, radius=1.7.dp.toPx(),center=p)
                        prev=p
                    } else prev=null
                }
            }
        }
        if(labels.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
            labels.filterIndexed { index,_ -> index==0 || index==labels.lastIndex/2 || index==labels.lastIndex }
                .forEach { Label(it,size=10) }
        }
    }
}

@Composable fun EmptyMetrics(onSync: ()->Unit) {
    PulseCard(Modifier.fillMaxWidth()) {
        Label("עדיין לא התקבלו מדידות. ודא ש־Samsung Health משתפת נתונים עם Health Connect ושאישרת הרשאות לקריאה.",size=14)
        Spacer(Modifier.height(12.dp))
        PulseButton("בדיקת סנכרון", onSync,Modifier.fillMaxWidth())
    }
}
