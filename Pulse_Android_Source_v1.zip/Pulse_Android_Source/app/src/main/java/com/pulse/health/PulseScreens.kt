package com.pulse.health

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val gap = 14.dp

@Composable fun DashboardScreen(store: HealthStore, navigate: (String)->Unit, sync: ()->Unit) {
    val steps = store.daily(Metric.STEPS, 1).lastOrNull()?.second
    val distance=store.daily(Metric.DISTANCE,1).lastOrNull()?.second
    val calories=store.daily(Metric.ACTIVE_CALORIES,1).lastOrNull()?.second
    val percent=(steps ?: 0.0).div(store.stepsGoal()).toFloat().coerceIn(0f,1f)
    LazyColumn(contentPadding=PaddingValues(horizontal=16.dp, vertical=16.dp), verticalArrangement=Arrangement.spacedBy(gap)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween, verticalAlignment=Alignment.CenterVertically) {
                Text("המדדים שלי", color=PulseColors.text, fontSize=23.sp, fontWeight=FontWeight.Bold)
                Label(if(store.lastSync()>0) "סונכרן ${timeText(store.lastSync())}" else "טרם בוצע סנכרון")
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                val h=store.last(Metric.HEART); val o=store.last(Metric.OXYGEN)
                DashboardTile("דופק",formatted(h?.value,Metric.HEART),"BPM",h?.let{timeText(it.time)}?:"אין מדידה",
                    PulseColors.heart, Icons.Outlined.FavoriteBorder,{navigate("heart")},Modifier.weight(1f))
                DashboardTile("חמצן בדם", formatted(o?.value,Metric.OXYGEN),"%",o?.let{timeText(it.time)}?:"אין מדידה",
                    PulseColors.oxygen, Icons.Outlined.WaterDrop,{navigate("oxygen")},Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                val s=store.last(Metric.SLEEP)
                DashboardTile("שינה", formatted(s?.value,Metric.SLEEP),"שע׳",s?.let{timeText(it.time)}?:"אין מדידה",
                    PulseColors.sleep, Icons.Outlined.NightsStay,{navigate("sleep")},Modifier.weight(1f))
                DashboardTile("קלוריות",formatted(calories,Metric.ACTIVE_CALORIES),"kcal","פעילות היום",
                    PulseColors.activity,Icons.Outlined.LocalFireDepartment,{navigate("activity")},Modifier.weight(1f))
            }
        }
        item { PulseSection("תנועה היום", "פירוט ›") }
        item {
            PulseCard(Modifier.fillMaxWidth(),onClick={navigate("steps")}) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Label("צעדים היום")
                        Value(formatted(steps,Metric.STEPS),size=36)
                        Label("מתוך יעד של ${store.stepsGoal()} צעדים")
                    }
                    CircularGoal(percent)
                }
                Spacer(Modifier.height(18.dp))
                LinearProgressIndicator(progress={percent}, modifier=Modifier.fillMaxWidth().height(7.dp),
                    color=PulseColors.primary, trackColor=PulseColors.primaryLight)
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                DashboardTile("מרחק",formatted(distance,Metric.DISTANCE),"ק״מ","היום",
                    PulseColors.activity,Icons.Outlined.Straighten,{navigate("activity")},Modifier.weight(1f))
                val w=store.last(Metric.WEIGHT)
                DashboardTile("משקל אחרון",formatted(w?.value,Metric.WEIGHT),"ק״ג",w?.let{timeText(it.time)}?:"אין מדידה",
                    PulseColors.primary,Icons.Outlined.MonitorWeight,{navigate("weight")},Modifier.weight(1f))
            }
        }
        item { PulseButton("סנכרון מדידות עכשיו",sync,Modifier.fillMaxWidth()) }
        item { Label("המדדים נלקחים מ־Health Connect לפי ההרשאות שאישרת; מדידות חסרות לא מוצגות כערך אפס.", size=12) }
    }
}

@Composable fun MetricScreen(kind: String, store: HealthStore, range: Int, onRange: (Int)->Unit, onSync: ()->Unit) {
    val data=store.primaryEntries(kind,range).sortedByDescending { it.time }
    val latest=data.firstOrNull()
    val color= when(kind) { Metric.HEART->PulseColors.heart;Metric.OXYGEN->PulseColors.oxygen;Metric.WEIGHT->PulseColors.primary; else ->PulseColors.activity }
    val icon= when(kind) { Metric.HEART -> Icons.Outlined.FavoriteBorder; Metric.OXYGEN->Icons.Outlined.WaterDrop; else->Icons.Outlined.MonitorWeight }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item {PeriodSelector(range,onRange)}
        item {
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Label("המדידה האחרונה",color=color)
                    MetricIcon(icon,color)
                }
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment=Alignment.Bottom) {
                    Value(formatted(latest?.value,kind),color=color,size=43)
                    Spacer(Modifier.width(8.dp)); Label(Metric.unit(kind),modifier=Modifier.padding(bottom=8.dp))
                }
                Label(latest?.let{"${timeText(it.time)} • ${it.origin}"} ?: "אין נתונים — בדוק הרשאות וסנכרון")
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                listOf("מינימום" to data.minOfOrNull{it.value},"ממוצע" to data.takeIf{it.isNotEmpty()}?.map{it.value}?.average(),"מקסימום" to data.maxOfOrNull{it.value}).forEach { (label,n) ->
                    PulseCard(Modifier.weight(1f)) {
                        Label(label,size=12)
                        Value(formatted(n,kind),size=18)
                    }
                }
            }
        }
        item { PulseSection("מגמת מדידות", "$range הימים האחרונים") }
        item {
            val chart=store.daily(kind,range)
            val averages = if (kind in listOf(Metric.HEART,Metric.OXYGEN,Metric.WEIGHT)) {
                val zone=ZoneId.systemDefault()
                val grouped=data.groupBy {Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate()}
                chart.map{(d,_) -> grouped[d]?.map{it.value}?.average()}
            } else chart.map{it.second}
            PulseCard(Modifier.fillMaxWidth()) {
                NativeChart(averages,color,labels=chart.map{it.first.format(DateTimeFormatter.ofPattern("dd/MM"))})
            }
        }
        item { PulseSection("היסטוריית מדידות", "${data.size} מדידות") }
        if(data.isEmpty()) item {EmptyMetrics(onSync)}
        else items(data.take(120),key={it.key}) {e ->
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column {Value("${formatted(e.value,kind)} ${Metric.unit(kind)}",size=17);Label(timeText(e.time),size=12)}
                    Label(e.origin,size=10)
                }
            }
        }
    }
}

@Composable fun StepsScreen(store: HealthStore, range: Int, onRange: (Int)->Unit, onSync: ()->Unit) {
    val days=store.daily(Metric.STEPS, range)
    var selected by remember(range) { mutableIntStateOf(days.lastIndex) }
    val values=days.map{it.second}
    val recorded=values.filterNotNull()
    val goal=store.stepsGoal()
    LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(gap)) {
        item {PeriodSelector(range,onRange)}
        item {
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column { Label("צעדים היום"); Value(formatted(values.lastOrNull(),Metric.STEPS),size=36); Label("היעד היומי $goal צעדים") }
                    CircularGoal(((values.lastOrNull()?:0.0)/goal).toFloat())
                }
            }
        }
        item {PulseSection("צעדים ב־$range ימים", "בחר עמודה כדי לראות יום")}
        item {
            PulseCard(Modifier.fillMaxWidth()) {
                NativeChart(values,PulseColors.primary,bars=true,labels=days.map{it.first.format(DateTimeFormatter.ofPattern("dd/MM"))}) {selected=it}
                Spacer(Modifier.height(12.dp))
                Label("${days[selected].first}: ${values[selected]?.toInt()?.toString() ?: "אין נתונים"} צעדים",color=PulseColors.primary)
            }
        }
        item {
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf("ממוצע ליום" to if(recorded.isEmpty()) "—" else formatted(recorded.average(),Metric.STEPS),
                    "סך צעדים" to if(recorded.isEmpty()) "—" else formatted(recorded.sum(),Metric.STEPS),
                    "יעד הושג" to "${recorded.count{it>=goal}} / ${recorded.size}").forEach{(label,v)->
                    PulseCard(Modifier.weight(1f)){Label(label,size=11);Value(v,size=16)}
                }
            }
        }
        item {PulseSection("היסטוריה יומית")}
        items(days.asReversed()) { (date,v) ->
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Text(date.toString(),color=PulseColors.text)
                    Value(v?.toInt()?.toString()?:"אין נתונים",size=16)
                }
            }
        }
        if(recorded.isEmpty()) item { EmptyMetrics(onSync) }
    }
}

@Composable fun SleepScreen(store: HealthStore, range: Int, onRange: (Int)->Unit, onSync: ()->Unit) {
    val sleepRecords=store.primaryEntries(Metric.SLEEP,range).sortedByDescending{it.time}
    val last=sleepRecords.firstOrNull()
    val today=LocalDate.now()
    val chart=(range-1 downTo 0).map { today.minusDays(it.toLong()) }.map{day->
        sleepRecords.filter{Instant.ofEpochMilli(it.end).atZone(ZoneId.systemDefault()).toLocalDate()==day}.maxByOrNull{it.end}?.value?.div(60.0)
    }
    val stages=remember(last?.key) {
        val amounts=mutableMapOf<Int,Long>()
        val arr=runCatching{JSONObject(last?.extra?:"").optJSONArray("stages")}.getOrNull()
        if(arr!=null) for(i in 0 until arr.length()) {
            val e=arr.optJSONObject(i)?:continue
            val k=e.optInt("type"); amounts[k]=(amounts[k]?:0)+((e.optLong("end")-e.optLong("start"))/60000).coerceAtLeast(0)
        }
        amounts
    }
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PeriodSelector(range,onRange)}
        item{
            PulseCard(Modifier.fillMaxWidth()) {
                Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth()) {
                    Column {Label("משך שינה אחרון");Value(formatted(last?.value,Metric.SLEEP),size=36);Label(last?.let{timeText(it.time)}?:"אין נתונים")}
                    MetricIcon(Icons.Outlined.NightsStay,PulseColors.sleep)
                }
            }
        }
        item{PulseSection("שלבי שינה")}
        item{
            PulseCard(Modifier.fillMaxWidth()) {
                if(stages.isEmpty()) Label("אין פירוט שלבי שינה זמין ממקור הנתונים")
                else listOf(5 to "שינה עמוקה",6 to "REM",4 to "שינה קלה",1 to "ערות",7 to "ערות במיטה",2 to "שינה לא מסווגת").forEach{(k,label)->
                    if(stages[k]!=null){
                        Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label);Value("${stages[k]} דקות",size=15)}
                        HorizontalDivider(color=PulseColors.border)
                    }
                }
            }
        }
        item{PulseSection("משך שינה ב־$range ימים")}
        item { PulseCard(Modifier.fillMaxWidth()) {NativeChart(chart,PulseColors.sleep,bars=true)} }
        item{PulseSection("לילות קודמים")}
        if(sleepRecords.isEmpty()) item{EmptyMetrics(onSync)}
        else items(sleepRecords,key={it.key}){e->
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween) {
                    Column{Value("${formatted(e.value,Metric.SLEEP)} שעות",size=19);Label("הירדמות ${timeText(e.time)}")}
                    Label("התעוררות ${timeText(e.end)}",size=11)
                }
            }
        }
    }
}

@Composable fun ActivityScreen(store: HealthStore, range: Int, onRange: (Int)->Unit, onSync: ()->Unit) {
    val exercises=store.primaryEntries(Metric.EXERCISE,range).sortedByDescending{it.time}
    val distance=store.daily(Metric.DISTANCE,range).mapNotNull{it.second}.sum()
    val calories=store.daily(Metric.ACTIVE_CALORIES,range).mapNotNull{it.second}.sum()
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PeriodSelector(range,onRange)}
        item{PulseSection("פעילות בתקופה")}
        item{
            Row(horizontalArrangement=Arrangement.spacedBy(7.dp)) {
                listOf("אימונים" to exercises.size.toString(),"מרחק" to "${formatted(distance,Metric.DISTANCE)} ק״מ", "קלוריות" to "${formatted(calories,Metric.ACTIVE_CALORIES)}").forEach{(label,v)->
                    PulseCard(Modifier.weight(1f)){Label(label,size=11);Value(v,size=16)}
                }
            }
        }
        item{PulseSection("מרחק יומי")}
        item{PulseCard(Modifier.fillMaxWidth()){NativeChart(store.daily(Metric.DISTANCE,range).map{it.second},PulseColors.activity,bars=true)}}
        item{PulseSection("אימונים")}
        if(exercises.isEmpty()) item{EmptyMetrics(onSync)}
        else items(exercises,key={it.key}){e->
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column {
                        Value(runCatching{JSONObject(e.extra).optString("title")}.getOrDefault("אימון"),size=18)
                        Label(timeText(e.time));Label("${e.value.toInt()} דקות • ${e.origin}",size=12)
                    }
                    MetricIcon(Icons.Outlined.DirectionsRun,PulseColors.activity)
                }
            }
        }
    }
}

@Composable fun HistoryScreen(store: HealthStore, range: Int, onRange: (Int)->Unit, navigate: (String)->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PeriodSelector(range,onRange)}
        item{PulseSection("היסטוריית מדידות","בחר קטגוריה")}
        items(Metric.all) {kind ->
            val data=store.primaryEntries(kind,range)
            PulseCard(Modifier.fillMaxWidth(),onClick={navigate(when(kind) {
                Metric.HEART,Metric.RESTING_HEART->"heart"
                Metric.OXYGEN->"oxygen";Metric.SLEEP->"sleep"; Metric.STEPS->"steps"
                Metric.EXERCISE,Metric.DISTANCE,Metric.ACTIVE_CALORIES,Metric.TOTAL_CALORIES->"activity"
                else->"weight"
            })}) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column{Value(Metric.label(kind),size=18);Label("${data.size} מדידות • ${data.firstOrNull()?.let{timeText(it.time)}?:"אין נתונים"}",size=12)}
                    Icon(Icons.Outlined.ChevronLeft,null,tint=PulseColors.primary)
                }
            }
        }
    }
}

@Composable fun GoalsScreen(store: HealthStore, navigate:(String)->Unit) {
    var editStep by remember{mutableStateOf(false)}
    var editWeight by remember{mutableStateOf(false)}
    var typed by remember{mutableStateOf("")}
    var stepGoal by remember{mutableIntStateOf(store.stepsGoal())}
    var weightGoal by remember{mutableFloatStateOf(store.weightGoal())}
    val today=store.daily(Metric.STEPS,1).lastOrNull()?.second
    val span=store.daily(Metric.STEPS,14).mapNotNull{it.second}
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PulseSection("יעד צעדים יומי")}
        item{
            PulseCard(Modifier.fillMaxWidth(),onClick={typed=stepGoal.toString();editStep=true}) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column{Label("יעד יומי");Value("$stepGoal",size=31);Label("היום: ${formatted(today,Metric.STEPS)} צעדים")}
                    CircularGoal(((today?:0.0)/stepGoal).toFloat())
                }
                Label("לחץ לשינוי היעד",color=PulseColors.primary)
            }
        }
        item{
            PulseCard(Modifier.fillMaxWidth()) {
                Value("${span.count{it>=stepGoal}} / ${span.size}",size=24)
                Label("ימים עם עמידה ביעד מתוך ימים שבהם קיימים נתונים")
            }
        }
        item{PulseSection("יעד משקל")}
        item{
            PulseCard(Modifier.fillMaxWidth(),onClick={typed=weightGoal.toString();editWeight=true}) {
                Label("משקל יעד")
                Value("${"%.1f".format(Locale.US,weightGoal)} ק״ג",size=26)
                Label("משקל אחרון ${formatted(store.last(Metric.WEIGHT)?.value,Metric.WEIGHT)} ק״ג")
                Label("לחץ לשינוי היעד",color=PulseColors.primary)
            }
        }
        item{PulseButton("גרף צעדים",{navigate("steps")},Modifier.fillMaxWidth())}
    }
    if(editStep || editWeight) {
        AlertDialog(onDismissRequest={editStep=false;editWeight=false},
            title={Text(if(editStep) "עריכת יעד צעדים" else "עריכת יעד משקל")},
            text={OutlinedTextField(value=typed,onValueChange={typed=it},singleLine=true,label={Text("יעד")})},
            confirmButton={TextButton(onClick={
                if(editStep) typed.toIntOrNull()?.takeIf{it in 100..100000}?.let{stepGoal=it;store.setStepsGoal(it)}
                if(editWeight) typed.toFloatOrNull()?.takeIf{it in 20f..400f}?.let{weightGoal=it;store.setWeightGoal(it)}
                editStep=false;editWeight=false
            }){Text("שמירה")}},
            dismissButton={TextButton(onClick={editStep=false;editWeight=false}){Text("ביטול")}})
    }
}

@Composable fun ReportsScreen(store: HealthStore, range: Int, onRange: (Int)->Unit,
    saveMd:(Set<String>)->Unit, saveJson:(Set<String>)->Unit,share:(Set<String>)->Unit) {
    val selected=remember{mutableStateMapOf<String,Boolean>().apply {Metric.all.forEach{put(it,true)} }}
    var notes by remember { mutableStateOf(store.notes()) }
    val included=selected.filterValues{it}.keys.toSet()
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PeriodSelector(range,onRange)}
        item{PulseSection("תוכן הדוח", "רק נתונים קיימים יופיעו")}
        items(Metric.all){kind->
            Row(Modifier.fillMaxWidth().heightIn(min=43.dp).clickable{selected[kind]=selected[kind]!=true},verticalAlignment=Alignment.CenterVertically) {
                Checkbox(checked=selected[kind]==true,onCheckedChange={selected[kind]=it},colors=CheckboxDefaults.colors(checkedColor=PulseColors.primary))
                Text(Metric.label(kind),color=PulseColors.text,fontSize=15.sp)
            }
        }
        item{PulseSection("הערות אישיות")}
        item{
            OutlinedTextField(value=notes,onValueChange={notes=it;store.setNotes(it)},modifier=Modifier.fillMaxWidth(),
                label={Text("הערות לדוח")},minLines=3,maxLines=5,shape=RoundedCornerShape(14.dp))
        }
        item{PulseButton("ייצוא Markdown (.md)",{saveMd(included)},Modifier.fillMaxWidth(),enabled=included.isNotEmpty())}
        item{PulseButton("ייצוא JSON",{saveJson(included)},Modifier.fillMaxWidth(),enabled=included.isNotEmpty())}
        item{OutlinedButton(onClick={share(included)},modifier=Modifier.fillMaxWidth(),enabled=included.isNotEmpty()) {Text("שיתוף דוח עם ChatGPT או אפליקציה אחרת")}}
        item{Label("שיתוף הדוח מתבצע רק בלחיצה שלך. Pulse אינה שולחת אוטומטית נתונים רפואיים לגורם חיצוני.",size=12)}
    }
}

@Composable fun SyncScreen(store: HealthStore, available:Boolean, granted:Set<String>,busy:Boolean,onPermission:()->Unit,onSync:()->Unit,
    navigate:(String)->Unit,openSamsung:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PulseSection("חיבור מקורות נתונים")}
        item{
            PulseCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically) {
                    Column{Value("Health Connect",size=20);Label(if(available) "זמין במכשיר" else "לא מותקן / דורש עדכון",color=if(available) PulseColors.activity else PulseColors.heart)}
                    MetricIcon(Icons.Outlined.HealthAndSafety,PulseColors.primary)
                }
                Spacer(Modifier.height(10.dp))
                Label("הרשאות מאושרות: ${granted.size} • סנכרון אחרון: ${if(store.lastSync()>0) timeText(store.lastSync()) else "טרם בוצע"}")
                Label("נתוני השעון מגיעים דרך Samsung Health → Health Connect → Pulse",size=12)
            }
        }
        item{
            PulseCard(Modifier.fillMaxWidth()) {
                Value("Samsung Health",size=20)
                Label("1. ודא ש־Samsung Health מחוברת לשעון ועברה סנכרון בטלפון",size=13)
                Label("2. Samsung Health ← הגדרות ← Health Connect ← הרשאות",size=13)
                Label("3. אפשר ל־Samsung Health לשתף את המדדים הרצויים",size=13)
                Label("4. אשר ל־Pulse הרשאות קריאה, ולחץ 'סנכרן'",size=13)
                Spacer(Modifier.height(10.dp))
                Label("החיבור אינו גישה ישירה לשעון. חלק מהמדדים אינם משותפים בכל גרסת Samsung Health.",size=12)
            }
        }
        item{OutlinedButton(onClick=openSamsung,modifier=Modifier.fillMaxWidth()){Text("פתח את Samsung Health")}}
        item{PulseButton("אישור הרשאות קריאה",onPermission,Modifier.fillMaxWidth(),enabled=available && !busy)}
        item{PulseButton(if(busy) "מסנכרן…" else "סנכרן עכשיו",onSync,Modifier.fillMaxWidth(),enabled=available && !busy)}
        item{if(store.lastError().isNotBlank()) Label("מידע מהסנכרון: ${store.lastError()}",color=PulseColors.heart)}
        item{PulseSection("עוד אפשרויות")}
        item{PulseCard(Modifier.fillMaxWidth(),onClick={navigate("goals")}){Value("יעדים ומעקב",size=18);Label("צעדים, משקל והתקדמות")}}
        item{PulseCard(Modifier.fillMaxWidth(),onClick={navigate("permission")}){Value("פרטיות והרשאות",size=18);Label("הסברים והגדרת גישה")}}
        item{Label("הנתונים נשמרים מקומית במכשיר. לא מתבצעת העלאה לענן של Pulse.",size=12)}
    }
}

@Composable fun PermissionScreen(granted:Set<String>,available:Boolean,onPermission:()->Unit) {
    LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(gap)) {
        item{PulseSection("הרשאות מדדי בריאות")}
        item{
            PulseCard(Modifier.fillMaxWidth()){
                Label(if(available) "Health Connect זמין" else "Health Connect אינו זמין", color=if(available) PulseColors.activity else PulseColors.heart)
                Label("Pulse מבקשת הרשאות לקריאה בלבד, ללא כתיבה או מחיקה של נתונים ב־Health Connect.")
            }
        }
        item{PulseButton("פתח בקשת הרשאות",onPermission,Modifier.fillMaxWidth(),enabled=available)}
        item{PulseSection("שקיפות ופרטיות")}
        item{
            PulseCard(Modifier.fillMaxWidth()){
                Label("• בכל מדד ללא הרשאה, תוצג הודעת 'אין נתונים'.")
                Label("• הגישה אינה כרוכה בהתחברות לחשבון Samsung או בהעלאה לשרת.")
                Label("• Health Connect שולטת בהרשאות וניתן לבטל אותן בכל עת.")
                Label("• הדוחות נוצרים במכשיר ומשותפים רק באישור יזום.")
            }
        }
    }
}
