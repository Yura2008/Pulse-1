package com.pulse.health

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.health.connect.client.permission.PermissionController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("DEPRECATION")
        window.statusBarColor = android.graphics.Color.rgb(38,43,104)
        @Suppress("DEPRECATION")
        window.navigationBarColor = android.graphics.Color.WHITE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        setContent {
            MaterialTheme(colorScheme=lightColorScheme(primary=PulseColors.primary,background=PulseColors.background,surface=PulseColors.card)) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    PulseApp()
                }
            }
        }
    }
}

@Composable
fun PulseApp() {
    val context=LocalContext.current
    val store=remember{HealthStore(context.applicationContext)}
    val source=remember{HealthConnectRepository(context.applicationContext)}
    val scope= rememberCoroutineScope()
    var page by rememberSaveable{mutableStateOf("dashboard")}
    var period by rememberSaveable{mutableIntStateOf(14)}
    var version by remember{mutableIntStateOf(0)}
    var syncing by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf("")}
    var granted by remember{mutableStateOf(emptySet<String>())}
    var pendingReport by remember{mutableStateOf("")}

    fun refreshPermissionsAndData() {
        if (!source.available || syncing) return
        scope.launch {
            syncing=true
            try {
                granted=source.grantedPermissions()
                if(granted.isEmpty()) {
                    message="לא ניתנו הרשאות. ניתן לאשר אותן בהגדרות."
                } else {
                    val result=withContext(Dispatchers.IO){source.sync(store,30)}
                    message="נקלטו ${result.saved} רשומות. " +
                        (if(result.issues.isEmpty()) "הסנכרון הושלם" else "בחלק מהמדדים חסרים נתונים/הרשאות")
                    version++
                }
            } catch(e:Exception) {
                message="בעיה בסנכרון: ${e.localizedMessage ?: "שגיאה לא ידועה"}"
            } finally{syncing=false}
        }
    }

    val permissionsLauncher= rememberLauncherForActivityResult(
        PermissionController.createRequestPermissionResultContract()
    ) { result ->
        granted=result
        refreshPermissionsAndData()
    }
    val onPermissions:()->Unit={
        if(source.available) permissionsLauncher.launch(source.requiredPermissions)
        else message="Health Connect אינו זמין; יש להתקין או לעדכן דרך הגדרות המכשיר"
    }
    val openSamsung:()->Unit={
        val intent=context.packageManager.getLaunchIntentForPackage("com.sec.android.app.shealth")
        if(intent!=null) context.startActivity(intent)
        else message="אפליקציית Samsung Health לא נמצאה בטלפון"
    }
    val onSync:()->Unit={
        if (!source.available) message="Health Connect אינו זמין במכשיר"
        else refreshPermissionsAndData()
    }

    LaunchedEffect(Unit) {
        if (source.available) {
            try {
                granted=source.grantedPermissions()
                if(granted.isNotEmpty()) refreshPermissionsAndData()
            } catch(e:Exception) {message=e.localizedMessage?:"שגיאה בקריאת הרשאות"}
        }
    }

    val exportLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if(uri!=null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use{it.write(pendingReport)}
                        ?: error("לא ניתן לפתוח את הקובץ לכתיבה")
                }
                message="הדוח נשמר בהצלחה"
            } catch(e:Exception) {message="לא ניתן לשמור את הדוח: ${e.localizedMessage}"}
        }
    }
    val saveMd:(Set<String>)->Unit={ included ->
        pendingReport=ReportBuilder.toMarkdown(store,period,included)
        exportLauncher.launch("Pulse-health-${LocalDate.now()}-$period-days.md")
    }
    val saveJson:(Set<String>)->Unit={ included ->
        pendingReport=ReportBuilder.toJson(store,period,included)
        exportLauncher.launch("Pulse-health-${LocalDate.now()}-$period-days.json")
    }
    val share:(Set<String>)->Unit={ included ->
        try {
            val dir=File(context.cacheDir,"reports").apply{mkdirs()}
            val file=File(dir,"Pulse-health-report.md").apply{writeText(ReportBuilder.toMarkdown(store,period,included),Charsets.UTF_8)}
            val uri=FileProvider.getUriForFile(context,"${context.packageName}.provider",file)
            val intent=Intent(Intent.ACTION_SEND).apply {
                type="text/markdown"
                putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent,"שיתוף דוח Pulse"))
        } catch(e:Exception) {message="השיתוף נכשל: ${e.localizedMessage}"}
    }

    Column(Modifier.fillMaxSize().background(PulseColors.background)) {
        PulseHeader(page, onBack={page="dashboard"}, onSettings={page="sync"})
        if(message.isNotBlank()) {
            Surface(color=PulseColors.primaryLight,modifier=Modifier.fillMaxWidth()) {
                Row(Modifier.padding(horizontal=12.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
                    Text(message,modifier=Modifier.weight(1f),color=PulseColors.text,fontSize=12.sp,lineHeight=17.sp)
                    IconButton(onClick={message=""},modifier=Modifier.size(32.dp)) {Icon(Icons.Outlined.Close,"סגור",tint=PulseColors.muted)}
                }
            }
        }
        // The version key re-reads the local SQLite cache after a completed sync.
        key(version) {
            Box(Modifier.weight(1f)) {
                when(page) {
                    "dashboard"->DashboardScreen(store,{page=it},onSync)
                    "heart"->MetricScreen(Metric.HEART,store,period,{period=it},onSync)
                    "oxygen"->MetricScreen(Metric.OXYGEN,store,period,{period=it},onSync)
                    "steps"->StepsScreen(store,period,{period=it},onSync)
                    "sleep"->SleepScreen(store,period,{period=it},onSync)
                    "weight"->MetricScreen(Metric.WEIGHT,store,period,{period=it},onSync)
                    "activity"->ActivityScreen(store,period,{period=it},onSync)
                    "history"->HistoryScreen(store,period,{period=it},{page=it})
                    "reports"->ReportsScreen(store,period,{period=it},saveMd,saveJson,share)
                    "sync"->SyncScreen(store,source.available,granted,syncing,onPermissions,onSync,{page=it},openSamsung)
                    "goals"->GoalsScreen(store,{page=it})
                    "missing"->Box(Modifier.fillMaxSize().padding(16.dp)){EmptyMetrics(onSync)}
                    "permission"->PermissionScreen(granted,source.available,onPermissions)
                    else->DashboardScreen(store,{page=it},onSync)
                }
            }
        }
        PulseBottomNav(page,onNavigate={page=it})
    }
}

@Composable private fun PulseHeader(page:String,onBack:()->Unit,onSettings:()->Unit) {
    val names=mapOf("dashboard" to "Pulse","heart" to "מעקב דופק","oxygen" to "חמצן בדם",
        "sleep" to "מעקב שינה","steps" to "צעדים","activity" to "פעילות גופנית",
        "history" to "היסטוריית מדידות","reports" to "דוחות וייצוא","sync" to "סנכרון נתונים",
        "goals" to "יעדים ומעקב","weight" to "משקל ומדדי גוף","missing" to "אין נתונים","permission" to "ניהול הרשאות")
    val title=names[page]?:"Pulse"
    val home=page=="dashboard"
    Box(Modifier.fillMaxWidth().height(105.dp).clip(RoundedCornerShape(bottomStart=26.dp,bottomEnd=26.dp))
        .background(PulseColors.headerGradient)) {
        Row(Modifier.fillMaxSize().padding(horizontal=16.dp),verticalAlignment=Alignment.CenterVertically,
            horizontalArrangement=Arrangement.SpaceBetween) {
            Column(modifier=Modifier.weight(1f)) {
                Text(title,fontSize=if(home) 34.sp else 27.sp,color=Color.White,fontWeight=FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text(if(home) "בוקר טוב, הנה תמונת הבריאות שלך" else "מדידות ומגמות לאורך זמן",fontSize=13.sp,color=Color.White.copy(alpha=.76f))
            }
            IconButton(onClick=if(home) onSettings else onBack,
                modifier=Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha=.13f))) {
                Icon(if(home) Icons.Outlined.NotificationsNone else Icons.Outlined.ArrowBackIosNew,if(home) "סנכרון" else "חזרה",tint=Color.White)
            }
        }
    }
}

@Composable private fun PulseBottomNav(page:String,onNavigate:(String)->Unit) {
    val tabs=listOf(
        Triple("dashboard","בית",Icons.Outlined.Home),Triple("heart","מדדים",Icons.Outlined.FavoriteBorder),
        Triple("history","היסטוריה",Icons.Outlined.History),Triple("reports","דוחות",Icons.Outlined.Description),
        Triple("sync","הגדרות",Icons.Outlined.Settings))
    HorizontalDivider(color=PulseColors.border)
    Row(Modifier.fillMaxWidth().height(70.dp).background(Color.White),verticalAlignment=Alignment.CenterVertically) {
        tabs.forEach{(id,title,icon)->
            val active=page==id || (id=="heart" && page in listOf("oxygen","sleep","weight","activity")) ||
                (id=="sync" && page in listOf("goals","permission")) || (id=="dashboard" && page=="steps")
            Column(Modifier.weight(1f).fillMaxHeight().clickable{onNavigate(id)}.padding(vertical=6.dp),
                horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.SpaceBetween) {
                Box(Modifier.size(39.dp).clip(RoundedCornerShape(13.dp)).background(if(active) PulseColors.primaryLight else Color.Transparent),contentAlignment=Alignment.Center) {
                    Icon(icon,title,tint=if(active) PulseColors.primary else PulseColors.muted,modifier=Modifier.size(24.dp))
                }
                Text(title,fontSize=11.sp,color=if(active) PulseColors.primary else PulseColors.muted,fontWeight=if(active) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
