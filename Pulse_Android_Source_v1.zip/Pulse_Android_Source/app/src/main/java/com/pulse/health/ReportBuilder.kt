package com.pulse.health

import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Human-readable and machine-readable exports stay on the phone until the user shares them. */
object ReportBuilder {
    private val zone = ZoneId.systemDefault()
    private val formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm", Locale("he", "IL")).withZone(zone)
    private fun timestamp(ms: Long) = formatter.format(Instant.ofEpochMilli(ms))
    private fun fmt(value: Double) = "%.2f".format(Locale.US, value)
    private fun summary(v: List<Double>): String = if (v.isEmpty()) "אין נתונים" else
        "אחרון ${fmt(v.first())}, ממוצע ${fmt(v.average())}, מינימום ${fmt(v.minOrNull() ?: 0.0)}, מקסימום ${fmt(v.maxOrNull() ?: 0.0)}"

    fun toJson(store: HealthStore, days: Int, included: Set<String>): String {
        val from = LocalDate.now(zone).minusDays((days - 1).toLong())
        val root = JSONObject()
            .put("app", "Pulse")
            .put("schema_version", "1.0")
            .put("exported_at", Instant.now().toString())
            .put("timezone", zone.id)
            .put("period_days", days)
            .put("start_date", from.toString())
            .put("end_date", LocalDate.now(zone).toString())
            .put("data_source", "Health Connect; source per reading")
            .put("medical_disclaimer", "מידע והכוונה בלבד. אינו אבחון רפואי")
            .put("notes", store.notes())
        val measurements = JSONObject()
        val stats = JSONObject()
        for (kind in Metric.all.filter { it in included }) {
            val entries = store.entries(kind, days).filter { Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate() >= from }
            measurements.put(kind, JSONArray().apply {
                entries.forEach { e -> addEntry(this, e) }
            })
            if (entries.isEmpty()) stats.put(kind, JSONObject().put("status", "no_data"))
            else {
                val nums = entries.map { it.value }
                stats.put(kind, JSONObject().put("unit", Metric.unit(kind)).put("count", nums.size)
                    .put("min", nums.minOrNull()).put("max", nums.maxOrNull()).put("average", nums.average()))
            }
        }
        root.put("measurements", measurements).put("statistics", stats)
        if (Metric.STEPS in included) {
            root.put("daily_steps", JSONArray().apply {
                store.daily(Metric.STEPS, days).forEach { (date, value) ->
                    put(JSONObject().put("date", date.toString()).put("steps", value ?: JSONObject.NULL)
                        .put("target", store.stepsGoal()).put("target_reached", if (value == null) JSONObject.NULL else value >= store.stepsGoal()))
                }
            })
        }
        return root.toString(2)
    }

    private fun addEntry(array: JSONArray, entry: HealthEntry) {
        val v = JSONObject().put("time", timestamp(entry.time)).put("time_epoch_ms", entry.time)
            .put("end_epoch_ms", entry.end).put("value", entry.value).put("unit", Metric.unit(entry.kind))
            .put("source", entry.origin)
        if (entry.extra.isNotBlank()) v.put("details", runCatching { JSONObject(entry.extra) }.getOrElse { entry.extra })
        array.put(v)
    }

    fun toMarkdown(store: HealthStore, days: Int, included: Set<String>): String = buildString {
        val from = LocalDate.now(zone).minusDays((days - 1).toLong())
        appendLine("# דוח בריאות — Pulse")
        appendLine()
        appendLine("תקופה: $from עד ${LocalDate.now(zone)} ($days ימים)  ")
        appendLine("הפקה: ${timestamp(System.currentTimeMillis())}  ")
        appendLine("מקור: Health Connect; מקור מדויק מפורט בכל מדידה.  ")
        appendLine("**אזהרה: דוח מידע בלבד, לא אבחון רפואי.**")
        appendLine()
        for (kind in Metric.all.filter { it in included }) {
            appendLine("## ${Metric.label(kind)} (${Metric.unit(kind)})")
            val data = store.entries(kind, days).filter { Instant.ofEpochMilli(it.time).atZone(zone).toLocalDate() >= from }
            appendLine("סיכום: ${summary(data.map { it.value })}")
            if (data.isEmpty()) appendLine("אין נתונים זמינים בתקופה זו.")
            else {
                appendLine("| תאריך ושעה | ערך | מקור |")
                appendLine("|---|---:|---|")
                data.forEach { e -> appendLine("| ${timestamp(e.time)} | ${fmt(e.value)} | ${e.origin} |") }
            }
            appendLine()
            if (kind == Metric.STEPS) {
                appendLine("### פירוט צעדים יומי (לא הופך חוסר נתונים ל־0)")
                appendLine("| יום | צעדים | יעד הושג |")
                appendLine("|---|---:|---|")
                store.daily(Metric.STEPS, days).forEach { (date, count) ->
                    appendLine("| $date | ${count?.toInt() ?: "אין נתונים"} | ${if (count == null) "לא ידוע" else if (count >= store.stepsGoal()) "כן" else "לא"} |")
                }
            }
        }
        if (store.notes().isNotBlank()) { appendLine("## הערות אישיות"); appendLine(store.notes()) }
        appendLine("\n---\nדוח שנוצר ב־Pulse; יש לפנות לאיש מקצוע לצורך פרשנות קלינית.")
    }
}
