package com.pulse.health

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView

/** Displayed from Health Connect's privacy/rationale entry point. */
class PermissionsRationaleActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 72, 48, 48)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
        }
        layout.addView(TextView(this).apply { textSize = 26f; text = "Pulse — פרטיות והרשאות" })
        layout.addView(TextView(this).apply {
            textSize = 17f
            text = "Pulse קוראת, באישורך, נתוני בריאות דרך Health Connect כדי להציג מדדים, גרפים, היסטוריה ודוחות. הנתונים נשמרים באופן מקומי בתוך האפליקציה ואינם מועברים לשרת. יצוא ושיתוף קבצים מתבצעים רק בפעולה יזומה שלך. ניתן לבטל הרשאות בהגדרות Health Connect בכל עת. Pulse אינה כלי לאבחון רפואי."
        })
        setContentView(layout)
    }
}
