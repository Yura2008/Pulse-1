package com.pulse.health

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/** Every entry comes from Health Connect. No fabricated or demo rows are inserted. */
data class HealthEntry(
    val key: String, val kind: String, val time: Long, val end: Long,
    val value: Double, val origin: String, val extra: String = ""
)

object Metric {
    const val HEART = "heart"
    const val RESTING_HEART = "resting_heart"
    const val OXYGEN = "oxygen"
    const val SLEEP = "sleep"
    const val STEPS = "steps"
    const val DISTANCE = "distance"
    const val ACTIVE_CALORIES = "active_calories"
    const val TOTAL_CALORIES = "total_calories"
    const val EXERCISE = "exercise"
    const val WEIGHT = "weight"
    const val BODY_FAT = "body_fat"
    val all = listOf(HEART, OXYGEN, SLEEP, STEPS, EXERCISE, DISTANCE, ACTIVE_CALORIES, TOTAL_CALORIES, WEIGHT, BODY_FAT, RESTING_HEART)
    fun label(k: String): String = when(k) {
        HEART -> "דופק"; RESTING_HEART -> "דופק במנוחה"; OXYGEN -> "חמצן בדם"
        SLEEP -> "שינה"; STEPS -> "צעדים"; DISTANCE -> "מרחק"; ACTIVE_CALORIES -> "קלוריות פעילות"
        TOTAL_CALORIES -> "קלוריות כוללות"; EXERCISE -> "פעילות גופנית"; WEIGHT -> "משקל"
        BODY_FAT -> "שומן גוף"; else -> k
    }
    fun unit(k: String): String = when(k) {
        HEART, RESTING_HEART -> "BPM"; OXYGEN, BODY_FAT -> "%"; SLEEP, EXERCISE -> "דקות"
        DISTANCE -> "ק״מ"; WEIGHT -> "ק״ג"; ACTIVE_CALORIES, TOTAL_CALORIES -> "kcal"; else -> ""
    }
}

class HealthStore(private val context: Context) : SQLiteOpenHelper(context, "pulse_health.db", null, 1) {
    private val preferences = context.getSharedPreferences("pulse_prefs", Context.MODE_PRIVATE)

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE health_entry (record_key TEXT PRIMARY KEY, kind TEXT NOT NULL, timestamp_ms INTEGER NOT NULL, end_ms INTEGER NOT NULL, value REAL NOT NULL, origin TEXT NOT NULL, extra TEXT NOT NULL)""")
        db.execSQL("CREATE INDEX entry_by_kind_time ON health_entry(kind, timestamp_ms DESC)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) = Unit

    fun saveBatch(entries: List<HealthEntry>) {
        if (entries.isEmpty()) return
        val db = writableDatabase
        db.beginTransaction()
        try {
            for (e in entries) {
                val values = ContentValues().apply {
                    put("record_key", e.key); put("kind", e.kind); put("timestamp_ms", e.time)
                    put("end_ms", e.end); put("value", e.value); put("origin", e.origin); put("extra", e.extra)
                }
                db.insertWithOnConflict("health_entry", null, values, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun entries(kind: String, days: Int = 30): List<HealthEntry> {
        val from = System.currentTimeMillis() - (days + 1L) * 86_400_000L
        val list = mutableListOf<HealthEntry>()
        readableDatabase.query("health_entry", null, "kind=? AND timestamp_ms>=?", arrayOf(kind, from.toString()), null, null, "timestamp_ms DESC", "200000").use { c ->
            val keyI=c.getColumnIndexOrThrow("record_key"); val kindI=c.getColumnIndexOrThrow("kind")
            val tsI=c.getColumnIndexOrThrow("timestamp_ms"); val endI=c.getColumnIndexOrThrow("end_ms")
            val valI=c.getColumnIndexOrThrow("value"); val oriI=c.getColumnIndexOrThrow("origin"); val extI=c.getColumnIndexOrThrow("extra")
            while (c.moveToNext()) list.add(HealthEntry(c.getString(keyI), c.getString(kindI), c.getLong(tsI), c.getLong(endI), c.getDouble(valI), c.getString(oriI), c.getString(extI)))
        }
        return list
    }
    fun last(kind: String): HealthEntry? = entries(kind).maxByOrNull { it.time }

    /** For daily time-series, prefer the data supplied by Samsung Health to avoid multi-app duplication. */
    fun primaryEntries(kind: String, days: Int): List<HealthEntry> {
        val data = entries(kind, days)
        val samsung = data.filter { it.origin == "com.sec.android.app.shealth" }
        if (samsung.isNotEmpty()) return samsung
        val most = data.groupingBy { it.origin }.eachCount().maxByOrNull { it.value }?.key
        return if (most != null) data.filter { it.origin == most } else emptyList()
    }

    /** Distribute interval quantities across local-day boundaries rather than assigning all to their start day. */
    fun daily(kind: String, days: Int): List<Pair<LocalDate, Double?>> {
        val zone = ZoneId.systemDefault()
        val today = LocalDate.now(zone)
        val totals = mutableMapOf<LocalDate, Double>()
        for (e in primaryEntries(kind, days + 1)) {
            val start = Instant.ofEpochMilli(e.time).atZone(zone)
            val end = Instant.ofEpochMilli(e.end.coerceAtLeast(e.time + 1)).atZone(zone)
            if (kind in listOf(Metric.STEPS, Metric.DISTANCE, Metric.ACTIVE_CALORIES, Metric.TOTAL_CALORIES)) {
                var cursor = start
                val fullMs = (e.end - e.time).coerceAtLeast(1).toDouble()
                while (cursor.isBefore(end)) {
                    val next = cursor.toLocalDate().plusDays(1).atStartOfDay(zone)
                    val to = if (next.isBefore(end)) next else end
                    val fraction = java.time.Duration.between(cursor, to).toMillis().toDouble() / fullMs
                    totals[cursor.toLocalDate()] = (totals[cursor.toLocalDate()] ?: 0.0) + e.value * fraction
                    cursor = to
                }
            } else {
                val day = start.toLocalDate()
                totals[day] = (totals[day] ?: 0.0) + e.value
            }
        }
        return (days - 1 downTo 0).map { today.minusDays(it.toLong()) }.map { it to totals[it] }
    }

    fun stepsGoal(): Int = preferences.getInt("steps_goal", 10000)
    fun setStepsGoal(value: Int) = preferences.edit().putInt("steps_goal", value).apply()
    fun weightGoal(): Float = preferences.getFloat("weight_goal", 75f)
    fun setWeightGoal(value: Float) = preferences.edit().putFloat("weight_goal", value).apply()
    fun notes(): String = preferences.getString("notes", "") ?: ""
    fun setNotes(value: String) = preferences.edit().putString("notes", value).apply()
    fun lastSync(): Long = preferences.getLong("last_sync", 0L)
    fun setLastSync() = preferences.edit().putLong("last_sync", System.currentTimeMillis()).apply()
    fun lastError(): String = preferences.getString("sync_error", "") ?: ""
    fun setLastError(value: String) = preferences.edit().putString("sync_error", value).apply()
}
