package com.pulse.health

import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.*
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.temporal.ChronoUnit
import kotlin.reflect.KClass

/**
 * Reads records actually published to Health Connect by Samsung Health or another authorized source.
 * This class DOES NOT connect directly to the Galaxy Watch; Samsung Health must publish the records.
 */
class HealthConnectRepository(private val context: Context) {
    val status: Int get() = HealthConnectClient.getSdkStatus(context)
    val available: Boolean get() = status == HealthConnectClient.SDK_AVAILABLE
    private val client: HealthConnectClient get() = HealthConnectClient.getOrCreate(context)

    val requiredPermissions: Set<String> = setOf(
        HealthPermission.getReadPermission(HeartRateRecord::class),
        HealthPermission.getReadPermission(RestingHeartRateRecord::class),
        HealthPermission.getReadPermission(OxygenSaturationRecord::class),
        HealthPermission.getReadPermission(SleepSessionRecord::class),
        HealthPermission.getReadPermission(StepsRecord::class),
        HealthPermission.getReadPermission(DistanceRecord::class),
        HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(TotalCaloriesBurnedRecord::class),
        HealthPermission.getReadPermission(ExerciseSessionRecord::class),
        HealthPermission.getReadPermission(WeightRecord::class),
        HealthPermission.getReadPermission(BodyFatRecord::class)
    )

    suspend fun grantedPermissions(): Set<String> = if(available) client.permissionController.getGrantedPermissions() else emptySet()

    private suspend fun <T : Record> readAll(type: KClass<T>, days: Int): List<T> {
        val results = mutableListOf<T>()
        val time = TimeRangeFilter.between(Instant.now().minus(days.toLong(), ChronoUnit.DAYS), Instant.now().plus(1, ChronoUnit.MINUTES))
        var token: String? = null
        do {
            val r = client.readRecords(ReadRecordsRequest(recordType = type, timeRangeFilter = time, pageSize = 1000, pageToken = token))
            results.addAll(r.records)
            token = r.pageToken
        } while (token != null)
        return results
    }

    /** One failing or denied type does not block the other measurements. */
    suspend fun sync(store: HealthStore, days: Int = 30): SyncResult {
        if (!available) return SyncResult(0, listOf("Health Connect אינו זמין במכשיר"), emptySet())
        val granted = grantedPermissions()
        val issues = mutableListOf<String>()
        var count = 0
        val from = days.coerceIn(1, 30)
        suspend fun <T : Record> collect(type: KClass<T>, label: String, convert: (T) -> List<HealthEntry>) {
            if (HealthPermission.getReadPermission(type) !in granted) {
                issues.add("אין הרשאה: $label")
                return
            }
            try {
                val records = readAll(type, from)
                val entries = records.flatMap(convert)
                store.saveBatch(entries)
                count += entries.size
            } catch (e: Exception) {
                issues.add("$label: ${e.localizedMessage ?: e.javaClass.simpleName}")
            }
        }
        collect(HeartRateRecord::class, "דופק") { r ->
            r.samples.mapIndexed { index, sample ->
                entry(r.metadata.id + ":$index", Metric.HEART, sample.time, sample.time, sample.beatsPerMinute.toDouble(), r.metadata.dataOrigin.packageName)
            }
        }
        collect(RestingHeartRateRecord::class, "דופק במנוחה") { r -> listOf(entry(r.metadata.id, Metric.RESTING_HEART, r.time, r.time, r.beatsPerMinute.toDouble(), r.metadata.dataOrigin.packageName)) }
        collect(OxygenSaturationRecord::class, "חמצן בדם") { r -> listOf(entry(r.metadata.id, Metric.OXYGEN, r.time, r.time, r.percentage.value, r.metadata.dataOrigin.packageName)) }
        collect(SleepSessionRecord::class, "שינה") { r ->
            val stages = JSONArray()
            r.stages.forEach { stage ->
                stages.put(JSONObject().put("type", stage.stage).put("start", stage.startTime.toEpochMilli()).put("end", stage.endTime.toEpochMilli()))
            }
            listOf(entry(r.metadata.id, Metric.SLEEP, r.startTime, r.endTime,
                java.time.Duration.between(r.startTime, r.endTime).toMinutes().toDouble(), r.metadata.dataOrigin.packageName,
                JSONObject().put("stages", stages).put("title", r.title ?: "").toString()))
        }
        collect(StepsRecord::class, "צעדים") { r -> listOf(entry(r.metadata.id, Metric.STEPS, r.startTime, r.endTime, r.count.toDouble(), r.metadata.dataOrigin.packageName)) }
        collect(DistanceRecord::class, "מרחק") { r -> listOf(entry(r.metadata.id, Metric.DISTANCE, r.startTime, r.endTime, r.distance.inMeters / 1000.0, r.metadata.dataOrigin.packageName)) }
        collect(ActiveCaloriesBurnedRecord::class, "קלוריות פעילות") { r -> listOf(entry(r.metadata.id, Metric.ACTIVE_CALORIES, r.startTime, r.endTime, r.energy.inKilocalories, r.metadata.dataOrigin.packageName)) }
        collect(TotalCaloriesBurnedRecord::class, "קלוריות כוללות") { r -> listOf(entry(r.metadata.id, Metric.TOTAL_CALORIES, r.startTime, r.endTime, r.energy.inKilocalories, r.metadata.dataOrigin.packageName)) }
        collect(ExerciseSessionRecord::class, "אימונים") { r ->
            listOf(entry(r.metadata.id, Metric.EXERCISE, r.startTime, r.endTime,
                java.time.Duration.between(r.startTime, r.endTime).toMinutes().toDouble(), r.metadata.dataOrigin.packageName,
                JSONObject().put("type", r.exerciseType).put("title", r.title ?: "אימון").toString()))
        }
        collect(WeightRecord::class, "משקל") { r -> listOf(entry(r.metadata.id, Metric.WEIGHT, r.time, r.time, r.weight.inKilograms, r.metadata.dataOrigin.packageName)) }
        collect(BodyFatRecord::class, "הרכב גוף") { r -> listOf(entry(r.metadata.id, Metric.BODY_FAT, r.time, r.time, r.percentage.value, r.metadata.dataOrigin.packageName)) }
        store.setLastSync()
        store.setLastError(issues.joinToString(" • "))
        return SyncResult(count, issues, granted)
    }

    private fun entry(id: String, kind: String, start: Instant, end: Instant, value: Double, origin: String, extra: String = "") =
        HealthEntry("$kind:$origin:$id", kind, start.toEpochMilli(), end.toEpochMilli(), value, origin, extra)
}

data class SyncResult(val saved: Int, val issues: List<String>, val granted: Set<String>)
