#!/usr/bin/env python3
"""Offline structural QA only; cannot replace Gradle, device or runtime testing."""
import hashlib, json, pathlib, re, xml.etree.ElementTree as ET
from PIL import Image
BASE=pathlib.Path(__file__).resolve().parents[1]
errors=[]
for file in (BASE/'app/src/main').rglob('*.xml'):
    try: ET.parse(file)
    except Exception as exc: errors.append(f'XML {file}: {exc}')
contract=json.loads((BASE/'references/design-contract.json').read_text(encoding='utf-8'))
resolution=contract['resolution']
for name, screen in contract['screens'].items():
    image=BASE/'references'/screen['file']
    if not image.is_file(): errors.append(f'Missing reference for {name}');continue
    if Image.open(image).size != (resolution['screen_width_px'],resolution['screen_height_px']): errors.append(f'Wrong reference dimensions for {name}')
    sha=hashlib.sha256(image.read_bytes()).hexdigest()
    if sha!=screen['sha256']:errors.append(f'Reference hash changed for {name}: {sha}')
contents='\n'.join(p.read_text(encoding='utf-8') for p in (BASE/'app/src/main/java').rglob('*.kt'))
for cls in ['HealthConnectClient','PermissionController','OxygenSaturationRecord','HeartRateRecord',
 'SleepSessionRecord','StepsRecord','ExerciseSessionRecord','WeightRecord','BodyFatRecord','ReadRecordsRequest',
 'ReportBuilder','CreateDocument','FileProvider']:
    if cls not in contents:errors.append(f'Missing functionality marker: {cls}')
for screen in ['dashboard','heart','oxygen','sleep','steps','activity','weight','history','reports','sync','goals','missing','permission']:
    if f'"{screen}"' not in contents: errors.append(f'Missing route: {screen}')
workflow=BASE/'.github/workflows/build-apk.yml'
if not workflow.is_file():errors.append('Missing GitHub CI workflow')
for permission in ['READ_HEART_RATE','READ_OXYGEN_SATURATION','READ_SLEEP','READ_STEPS','READ_DISTANCE','READ_EXERCISE','READ_WEIGHT']:
    if permission not in (BASE/'app/src/main/AndroidManifest.xml').read_text(): errors.append(f'Missing permission {permission}')
report={'kind':'OFFLINE_STATIC_AUDIT','references':len(contract['screens']),'expected_dimensions':resolution['screen_width_px:screen_height_px'] if 'screen_width_px:screen_height_px' in resolution else [resolution['screen_width_px'],resolution['screen_height_px']], 'errors':errors,'compiled':False,'device_tested':False,'pixel_matched':False}
print(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(1 if errors else 0)
